<?php

namespace Scheduler\Exception;

/**
 * Class SchedulerException
 * @package Scheduler
 * @author Aleh Hutnikau, <goodnickoff@gmail.com>
 */
class SchedulerException extends \Exception
{
}